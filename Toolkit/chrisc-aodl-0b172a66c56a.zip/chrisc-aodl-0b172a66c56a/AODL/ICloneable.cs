namespace AODL
{
    public interface ICloneable
    {
        object Clone();
    }
}