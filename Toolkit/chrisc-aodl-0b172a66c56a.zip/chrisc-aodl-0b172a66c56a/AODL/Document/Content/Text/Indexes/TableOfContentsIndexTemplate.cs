/*************************************************************************
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * Copyright 2008 Sun Microsystems, Inc. All rights reserved.
 * 
 * Use is subject to license terms.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0. You can also
 * obtain a copy of the License at http://odftoolkit.org/docs/license.txt
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 ************************************************************************/

using System.Xml.Linq;

namespace AODL.Document.Content.Text.Indexes
{
    /// <summary>
    /// TableOfContentsIndexTemplate represent the table of content
    /// index template. It is used to set the index entries and their
    /// order within a table of content.
    /// A common order would be:
    /// Chapter Text TabStop PageNumber
    /// </summary>
    public class TableOfContentsIndexTemplate
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TableOfContentsIndexTemplate"/> class.
        /// </summary>
        /// <param name="tableOfContents">Content of the table of.</param>
        /// <param name="outlineLevel">For which outline level this template should be used.</param>
        /// <param name="styleName">Style name.</param>
        public TableOfContentsIndexTemplate(TableOfContents tableOfContents, int outlineLevel, string styleName)
        {
            TableOfContents = tableOfContents;
            NewXmlNode(outlineLevel, styleName);
        }

        /// <summary>
        /// Gets or sets the node.
        /// </summary>
        /// <value>The node.</value>
        public XElement Node { get; set; }

        /// <summary>
        /// Gets or sets the content of the table of.
        /// </summary>
        /// <value>The content of the table of.</value>
        public TableOfContents TableOfContents { get; set; }

        /// <summary>
        /// Inits the standard template.
        /// </summary>
        public void InitStandardTemplate()
        {
            if (TableOfContents.UseHyperlinks)
                InsertIndexEntry(IndexEntryTypes.HyperlinkStart);

            InsertIndexEntry(IndexEntryTypes.Chapter);
            InsertIndexEntry(IndexEntryTypes.Text);

            if (TableOfContents.UseHyperlinks)
                InsertIndexEntry(IndexEntryTypes.HyperlinkEnd);

            InsertIndexEntry(IndexEntryTypes.TabStop);
            InsertIndexEntry(IndexEntryTypes.PageNumber);
        }

        /// <summary>
        /// Insert a index entry to the template.
        /// You can define the order through the order you insert
        /// the index entry types.
        /// </summary>
        /// <param name="indexEntryType">Type of the index entry.</param>
        public void InsertIndexEntry(IndexEntryTypes indexEntryType)
        {
            if (indexEntryType == IndexEntryTypes.Chapter)
            {
                AddIndexEntryNode("index-entry-chapter", indexEntryType);
            }
            else if (indexEntryType == IndexEntryTypes.Text)
            {
                AddIndexEntryNode("index-entry-text", indexEntryType);
            }
            else if (indexEntryType == IndexEntryTypes.TabStop)
            {
                AddIndexEntryNode("index-entry-tab-stop", indexEntryType);
            }
            else if (indexEntryType == IndexEntryTypes.PageNumber)
            {
                AddIndexEntryNode("index-entry-page-number", indexEntryType);
            }
            else if (indexEntryType == IndexEntryTypes.HyperlinkStart)
            {
                AddIndexEntryNode("index-entry-link-start", indexEntryType);
            }
            else if (indexEntryType == IndexEntryTypes.HyperlinkEnd)
            {
                AddIndexEntryNode("index-entry-link-end", indexEntryType);
            }
        }

        /// <summary>
        /// Create the XElement which represent this object.
        /// </summary>
        /// <param name="outlineLevel">For which outline level this template should
        /// be used.</param>
        /// <param name="styleName">The name of the style which is referenced with
        /// this template</param>
        private void NewXmlNode(int outlineLevel, string styleName)
        {
            Node = new XElement(Ns.Text + "table-of-content-entry-template");
            Node.SetAttributeValue(Ns.Text + "outline-level", outlineLevel.ToString());
            Node.SetAttributeValue(Ns.Text + "style-name", styleName);
        }

        /// <summary>
        /// Add the index entry node, with given type
        /// </summary>
        /// <param name="nodeName">Name of the node.</param>
        /// <param name="indexEntryType">Type of the index entry.</param>
        private void AddIndexEntryNode(string nodeName, IndexEntryTypes indexEntryType)
        {
            XElement indexEntryNode = new XElement(Ns.Text + nodeName);

            if (indexEntryType == IndexEntryTypes.TabStop)
            {
                //Fixed to be right align
                indexEntryNode.SetAttributeValue(Ns.Style + "type", "right");
                //Fixed usage of .
                indexEntryNode.SetAttributeValue(Ns.Style + "leader-char", ".");
            }

            Node.Add(indexEntryNode);
        }
    }

    /// <summary>
    /// The possible index entry types
    /// </summary>
    public enum IndexEntryTypes
    {
        /// <summary>
        /// Index entry type Chapter
        /// </summary>
        Chapter,
        /// <summary>
        /// Index entry type Text
        /// </summary>
        Text,
        /// <summary>
        /// Index entry type TabStop
        /// </summary>
        TabStop,
        /// <summary>
        /// Index entry type PageNumber
        /// </summary>
        PageNumber,
        /// <summary>
        /// Index entry type Hyperlink start
        /// </summary>
        HyperlinkStart,
        /// <summary>
        /// Index entry type Hyperlink start
        /// </summary>
        HyperlinkEnd
    }
}

/*
 * $Log: TableOfContentsIndexTemplate.cs,v $
 * Revision 1.2  2008/04/29 15:39:47  mt
 * new copyright header
 *
 * Revision 1.1  2007/02/25 08:58:40  larsbehr
 * initial checkin, import from Sourceforge.net to OpenOffice.org
 *
 * Revision 1.1  2006/01/29 11:28:22  larsbm
 * - Changes for the new version. 1.2. see next changelog for details
 *
 * Revision 1.1  2006/01/05 10:31:10  larsbm
 * - AODL merged cells
 * - AODL toc
 * - AODC batch mode, splash screen
 *
 */