using AODL.Document.Collections;

namespace AODL.Document.Custom
{
    public class CustomFileCollection : CollectionWithEvents<ICustomFile>
    {
    }
}