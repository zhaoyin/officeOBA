Before you can compile and run the AODLTest project 
you have to install the current version of NUnit.
You can download NUnit from their project website:

http://nunit.com/index.php?p=download

After you have installed NUnit you have also to change 
the assembly reference settings to point to your installed
NUnit version. The required assembly is nunit.framework.dll.
Which can be found inside the bin folder of NUnit.

If you still have any questions or need any other further
help you're welcome to post your question on the ODF Toolkit
mailing list. http://odftoolkit.openoffice.org

More information about AODL and examples can be found on the 
AODL wiki pages: http://wiki.services.openoffice.org/wiki/AODL

Lars Behrmann, Lars.Behrmann@Sun.com

last change: $Author: larsbehr $ $Date: 2007/08/15 06:28:11 $

