﻿XML-RPC.NET - XML-RPC for .NET 
v3.0.0 Release
Copyright (C) 2001-2010 Charles Cook (chascook@gmail.com)

xmlrpcgen 
Copyright (C) 2003 Joe Bork

nunit
Copyright � 2002-2004 James W. Newkirk, Michael C. Two, Alexei A. Vorontsov, Charlie Poole
Copyright � 2000-2004 Philip A. Craig



For more information about XML-RPC.NET visit http://www.xml-rpc.net.

XML-RPC.NET is licensed with MIT X11 license.
(see http://www.xml-rpc.net/faq/xmlrpcnetfaq.html#6.12)

For more information about XML-RPC refer to http://www.xmlrpc.com/


PREQUISITES
-----------
Assemblies CookComputing.XmlRpcV3.dll and CookComputing.XmlRpcServerV3.dll 
require 2.0 .NET runtime and run on all later versions.

Assembly CookComputing.XmlRpcSilverlightV3.dll requires Silverlight 3 or Silverlight 4 runtime.

DOCUMENTATION
-------------
For help on using XML-RPC.NET, see 
http://www.xml-rpc.net/faq/xmlrpcnetfaq.html.