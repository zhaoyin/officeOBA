XML-RPC.net
===========

XML-RPC.net port to Xamarin

v.2.5.0

[http://xml-rpc.net/download.html](http://xml-rpc.net/download.html)