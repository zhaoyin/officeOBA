The file Xceed.Wpf.Samples.SampleData.dll has been created from Xceed.Silverlight.Samples.SampleData.dll of the Silverlight ListBox.
Only the Silverlight has been changed to Wpf.