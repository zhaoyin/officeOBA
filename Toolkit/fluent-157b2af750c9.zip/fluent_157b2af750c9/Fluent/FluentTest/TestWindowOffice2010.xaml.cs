namespace FluentTest
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class TestWindowOffice2010
    {
        public TestWindowOffice2010()
        {
            this.InitializeComponent();
        }
    }
}