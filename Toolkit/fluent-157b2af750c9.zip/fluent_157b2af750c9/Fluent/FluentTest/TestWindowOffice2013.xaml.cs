﻿namespace FluentTest
{
    public partial class TestWindowOffice2013
    {
        public TestWindowOffice2013()
        {
            this.InitializeComponent();
        }
    }
}