﻿using System.Reflection;

[assembly: AssemblyTitle("Fluent Showcase")]
[assembly: AssemblyDescription("Showcase of Fluent Ribbon Control Suite")]