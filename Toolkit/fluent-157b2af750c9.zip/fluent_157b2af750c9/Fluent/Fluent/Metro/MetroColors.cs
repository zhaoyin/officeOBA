﻿namespace Fluent
{
    using System.Windows;

    public static class MetroColors
    {
        public static readonly ComponentResourceKey ThemeColorKey = new ComponentResourceKey(typeof(MetroColors), "ThemeColor");
    }
}