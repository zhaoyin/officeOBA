﻿#region Copyright and License Information

// Fluent Ribbon Control Suite
// http://fluent.codeplex.com/
// Copyright © Degtyarev Daniel, Rikker Serg., Weegen Patrick 2009-2013.  All rights reserved.
// 
// Distributed under the terms of the Microsoft Public License (Ms-PL). 
// The license is available online http://fluent.codeplex.com/license

#endregion

namespace Fluent.Sample.Mvvm
{
    /// <summary>
    /// Entry point of the application
    /// </summary>
    public partial class Application : System.Windows.Application
    {
    }
}